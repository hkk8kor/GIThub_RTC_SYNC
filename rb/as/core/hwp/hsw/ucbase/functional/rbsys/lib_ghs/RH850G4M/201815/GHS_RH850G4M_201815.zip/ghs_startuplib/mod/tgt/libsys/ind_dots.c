#if defined(EMBEDDED)
#error "ind_dots.c is invalid. write an assembly version for your target."
#endif
