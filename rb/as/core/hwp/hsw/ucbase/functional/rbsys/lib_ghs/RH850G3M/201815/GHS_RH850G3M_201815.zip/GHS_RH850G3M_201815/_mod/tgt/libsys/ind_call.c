#if defined(EMBEDDED)
#error "ind_call.c is not valid. write an assembly version for your target."
#endif
