#if defined(EMBEDDED)
#error "ind_multicore_hlp.c is not valid. write an assembly version for your target."
#endif
