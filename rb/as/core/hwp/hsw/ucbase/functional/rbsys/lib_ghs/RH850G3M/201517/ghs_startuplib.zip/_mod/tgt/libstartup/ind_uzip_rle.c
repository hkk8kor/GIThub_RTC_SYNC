/*
                      Low-Level Startup Library

            Copyright 2014 Green Hills Software, Inc.

    This program is the property of Green Hills Software, Inc,
    its contents are proprietary information and no part of it
    is to be disclosed to anyone except employees of Green Hills
    Software, Inc., or as agreed in writing signed by the President
    of Green Hills Software, Inc.
*/
/* Decompress PackBits (run length encoded) data */

#include "ind_startup.h"

#pragma ghs section text=".boottext" 

syze_t __ghs_decompress_rle(void *dst, const void *src, syze_t n)
{
    int i = 0;
    signed char* d = (signed char*)dst;
    signed char* s = (signed char*)src;
    signed char hbyte;
    int j = 0;
    while(i<n) {
	hbyte = s[i];
	/* raw data */
	if(hbyte >= 0) {
	    int ct = hbyte+1;
	    i++;
	    for(j=0; j<ct; j++) {
		*d = s[i+j];
		d++;
	    }
	    i+=ct;
	/* a run */
	} else if(hbyte > -128) {
	    int ct = 1-hbyte;
	    unsigned char c = s[i+1];
	    for(j=0; j<ct; j++) {
		*d = c;
		d++;
	    }
	    i+=2;
	} else /* -128 : nop */ {
	    i++;
	}
    }
    return d-(signed char*)dst;
}
